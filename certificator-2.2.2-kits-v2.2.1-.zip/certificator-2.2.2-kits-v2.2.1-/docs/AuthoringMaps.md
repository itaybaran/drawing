# Editing & Authoring Mappings (Actions)
The basic functional building block of a test run is the Action entity. This is essentially a Mapping file that resides in the `maps` folder. Each map file's name must be purely alphanumeric (no dashes, spaces, underscores, or any other special characters) and the extension is `.txt`.
The filename will be used as the mapping id and can be referenced in the following places:
1. In the `kits.json` file - To define metadata about the Action and where in the kit(s) it is being used.
2. Inside other mappings - You can call a mapping from another mapping just like any other function, e.g: `$myMappingId({})` calls the mapping saved as `maps\myMappingId.txt` and passes an empty object as the input.

**Note** - Any changes in the `maps` folder content (new files, changes in existing files, file deletion) are only reflected after a restart of the Certificator app, since the folder is scanned and loaded only once at start-up.

## Dev UI
To assist in authoring and testing Mappings, there is a basic web interface at `http://localhost:8400/dev`. The top pane is the (optional) input to the mapping and must be a valid JSON document.  
The second pane is the Mapping expression itself.  
Pressing the `Run` button runs the Mapping on the provided input (empty input translates to an empty object), and any response data is displayed in the bottom pane.

## Syntax
The syntax for the mapping logic is the FUME syntax, which is based on JSONata. To understand the existing tests and author new ones, review the [JSONata documentation](https://docs.jsonata.org/overview.html) and [FUME documentation](https://www.fume.health/).

## Functions
Additional functions have been added to support common activities required in this project:

### $validate(resources [, profiles])
Runs validation (using the background HL7 Validator server) on an array of `resources` (as JSON objects), optionally against the provided array of `profiles` (canonical URLs).
Please read the [validator background process](README.md#validator-background-process---on-first-call) section in the README for important information about the usage and behavior of this function.

Returns an array of validation result objects, in the same order as the input array.  
Each result object contains an `issues` array with errors, warnings and/or information from the HL7 Validator.  
It is possible to pass a single resource instead of an array, in which case the result will also be a single result object.

### $writeFile(content, filepath)

Writes a file under the `io` directory, or a sub-path of it. If the file already exists, it is overwritten. When a sub-path is provided, the immediate parent folder must already exist (use `$makeDir()` if needed).

- **content**: a string or any JSON value. If `content` is undefined, the function exits early (does nothing).
  - If a **string** is provided, it is written verbatim (no extra quoting/escaping).
  - If a **non-string JSON value** is provided, it is serialized to JSON (UTF-8, **not** pretty-printed). The target **SHOULD** use a `.json` extension.
- **filepath**: file name or relative path **within** the `io` directory. 

**Returns:** `undefined`.  
**Throws:** on invalid path, missing parent directory, serialization failure, or I/O errors.


### $readFile(filepath)
Reads a file from the `io` folder.
- `filepath`: File name or path. Relative to the `io` folder.  

Returns the contents of the file. JSON files will be parsed and returned as JSON values. Other files will be returned as a `string`.  
If the file is not found, returns `undefined` (not an error).

### $makeDir(path)
Creates a directory or a chain of directories (e.g., `level1/level2/level3`) inside the `io` folder. If any of the path steps already exist, it is NOT an error, and the contents of the folder will not be cleared. Can be used to ensure an internal path exists prior to performing `$writeFile` operations on internal paths.
- `path`: Directory name or path. Relative to the `io` folder.

Returns `undefined` or an error.

### $readDir( [subPath] )
Reads the content of a folder. If `subPath` is not provided, the contents of the `io` folder will be returned. If a sub-path is provided, it will be treated as an internal path inside `io`, and the contents of the internal folder will be returned.
- `subPath`: Directory name or path. Relative to the `io` folder. Defaults to `io` itself.

Returns an array of file names (string), or an empty array (if folder is empty), or throws an error.

### $setStatus(code, display [, details] )
This function is bound to each mapping when it is loaded from the `maps` folder, and makes it easy to write custom Action statuses and information. The `code` (string) argument must be one of the valid status codes (e.g. 'passed', 'failed'), the `display` (string) should be the corresponding human-friendly value of it ('Passed', 'Failed' etc.) and the optional `details` (string) may contain any additional information about the status.  

**Notes**:
1. It is not required to use this function if you don't want to report a custom status. The regular workflow statuses `init`, `in-progress`, `completed` and `error` are handled automatically. The most common use for this function is in objective tests, where internal mapping logic is performed to determine if the action passed or failed.
2. When running an expression from the dev UI (not saved as a file in `maps`, i.e "anonymous" map), this function has no effect (and using it in this context **will not throw** an error). This is because statuses are only reported during an orchestrated run of a Test Kit, and it requires a Mapping ID (which is only assigned when a mapping is loaded from a file).

### $instant()
Returns the current exact timestamp in milliseconds. This differs from JSONata's built-in `$now()` and `$millis()` functions, which return the same value throughout a single evaluation (the execution start time).  
It is useful for measuring times between different steps in a Mapping.

### $http(HttpOptions)
Performs an HTTP(s) call. The default Base URL for a request is the FHIR Server configured for the current [Environment](EnvironmentVariables.md). This project uses this bare-bones approach when interacting with the FHIR server (and not the native FUME functions `$search()`, `$resolve()`, etc.) because in a certification framework we cannot assume that the FHIR endpoint behaves according to the standard. Using a direct HTTP call and processing its full response (and handling exceptions and errors gracefully) is essential.  
This function is a wrapper for an [Axios Instance](https://axios-http.com/docs/instance), where the `HttpOptions` argument is mapped internally to the [Axios Request Config](https://axios-http.com/docs/req_config) interface, and the returned object is an instance of the [Axios Response Schema](https://axios-http.com/docs/res_schema).

These are the available config options for the mandatory `HttpOptions` object argument. All properties are optional. `url` SHALL be a relative URL. If both `url` and `baseUrl` are not specified, the default endpoint will be the FHIR server's base address. Requests default to GET if `method` is not specified.  
If you need to access a base address different from the default FHIR server, pass an absolute URL in `baseUrl`, and optionally append an additional path by passing a relative URL in `url`.

HttpOptions:
```
{
  'method': <string, default: 'get'>,
  'headers': { 'key': 'value' ... },
  'url': <string, default: '/'>,
  'baseUrl': <string, default: $fhirServer>,
  'body': <JSON>,
  'params': { 'key': 'value' ... },
  'timeout': <number, default: 10000ms>
}
```
Note: both `header` and `headers` are supported for legacy reasons, but only one of them should be provided, and `headers` is preferred (aligns with Axios).

Example call to $http() inside a Mapping:
```
$readResponse := $http({
  'method':'get',
  'headers' : {'accept': 'application/fhir+json'},
  'url': 'metadata'
})
```

This will perform a GET request against the FHIR Server's `metadata` endpoint, and return the full Axios Response object, including status, headers, and body. A conformant server should respond to this request with its CapabilityStatement resource in JSON format.  
*Note*: The $http() function will NOT fail on HTTP error codes. This is by design. This means you should always inspect the response's `status` element to see, for example, if the code is in the 2xx range or not.
The actual body contents of the response can be accessed using the `data` element:

```
$readResponse.data // *should* be the actual CapabilityStatement JSON returned by the FHIR server
```

### $resolveCanonical(url)
Searches the FHIR Package Cache for a conformance resource with the provided `url` (string).

### $newCache( [initial] )
Creates a mutable, Map-like cache object for use inside mappings. You must assign the created cache to a variable and call that variable's methods to mutate the internal state.

Notes:
- Always do `$cache := $newCache()` and then call `$cache.set(...)`, `$cache.update(...)`, etc.
- Mutations happen inside the cache object; the variable reference stays the same.

Supported methods on the returned cache object:
- `set(key, value)` → stores and returns `value`.
- `get(key, default?)` → returns value or `default` if missing.
- `has(key)` → boolean.
- `delete(key)` → boolean.
- `clear()` → empties cache; returns `null` (useful for chaining).
- `size()` → number of entries.
- `keys()` / `values()` → arrays.
- `entries()` → array of `{ key, value }` objects.
- `getOrSet(key, initOrFn)` → returns existing or initializes with `initOrFn` (value or function) and returns it.
- `update(key, updaterFn)` → computes next value from current using `updaterFn(current)`; stores and returns it.
- `toObject()` → plain object view of the cache (keys are stringified).

Initialization:
- `$newCache()` → empty cache.
- `$newCache({'a':1,'b':2})` → from plain object.
- `$newCache([['a',1],['b',2]])` → from entries array.

Example:
```
(
  $cache := $newCache();
  $cache.set('a', 100);
  $cache.get('a') + 1  /* => 101 */
)
```

## Variables
In addition to the added functions, some global variables have been defined to enable access to useful values from within mappings. These are the variables and their usage:

### $fhirServer
Holds the URL (string) of the FHIR endpoint as configured in the [Environment Variables](EnvironmentVariables.md).

### $sampleSize
Holds the sample size (number) as configured in the [Environment Variables](EnvironmentVariables.md) or the default value of 1000 if not configured otherwise.

## Utility mappings

### utilGetAllSampledResourceFilenames
Resources sampled from the server are stored in the `io` folder and have a consistent naming convention of `[<resourceType>]_[<id>].json`. Many maps rely on this convention when loading sampled resources for processing, but many other files are written into the `io` folder so filtering by filename pattern must be performed. This central utility map was created to provide this filtering functionality in a single, reusable place.
- Signature: `$utilGetAllSampledResourceFilenames(filenames, {'types': [string, string, ...]})`
- Inputs:
  - `filenames` (array): The full list of files residing in the `io` folder. Filtering is done on this list - this utility **does not read the folder directly**
  - { `options`} *optional*
    - `types` (array): If provided, only files of the provided resourceType list will be returned. If not provided, all resource types will be returned

**Note:** The reason this map does not read the contents of the folder directly but relies on the caller providing the input is to simplify testing. If the caller map has been injected with a mock `$readDir`, we want **that** version of `readDir` to determine the list of filenames that represent the (virtual) `io` folder content. Letting the utility read the folder directly will lead to it getting a different list than the caller would. This is a common "dependency injection" pattern.

### $utilFindFirst
Find the first element in an array that satisfies a predicate function, using a simple recursive scan.

- Signature: `$utilFindFirst(array)(predicateFn)`
- Inputs:
  - `array`: Any JSON value. If not an array, it will be treated as `[value]`.
  - `predicateFn`: `function($item) -> boolean`. Must return a truthy value for a match.
- Returns: The first matching item, or `undefined` if no match is found.

Usage examples:
```
// Find first number greater than 10
$utilFindFirst([0, 1, 3, 12, 5])(function($item){ $item > 10 })  /* => 12 */

// Find first active object
$utilFindFirst([
  {"id":"a","active":false},
  {"id":"b","active":true},
  {"id":"c","active":true}
])(function($x){ $x.active })  /* => {"id":"b","active":true} */

// Non-array input is treated as a single-item array
$utilFindFirst({"a":1})(function($x){ $exists($x.a) })  /* => {"a":1} */

// No match → undefined
$utilFindFirst([1,2,3])(function($n){ $n > 100 })  /* => undefined */
```

Notes:
- This is a mapping in the `maps` folder and can be invoked from other mappings like a function.
- Pass the array as the mapping input; the returned value is a function you call with your predicate.