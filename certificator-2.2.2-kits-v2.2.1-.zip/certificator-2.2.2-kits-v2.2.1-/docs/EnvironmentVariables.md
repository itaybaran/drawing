# IL FHIR Certificator Environment Variables
The Certificator uses several environment variables that configure its settings and behavior.


## 🛠 Setup & Usage
The variables may be set directly at the system or user level (for advanced users), or it may be set in a text file named `.env` located at the installation folder. 

When first running the application, if a `.env` file is missing you will be guided through entering the different mandatory settings and the `.env` file will be created for you. You may edit this file later if you want to change or add variables. 

Note: If you edit the `.env` while the Certificator is running, a **restart** is required for the changes to take affect.

Bellow are the variables and their usage.

## ⚙️ Variables

### 📌FHIR_SERVER_BASE
The FHIR Server address. This is the endpoint that will be tested. It may be either an absolute URL or an IP address. May include a port number.
Note: When using an IP address it MUST be formatted as a URL (prefixed with `http:` or `https:`).

Examples in ENV file:  
`FHIR_SERVER_BASE=https://server.fire.ly/r4`  
`FHIR_SERVER_BASE=http://10.5.90.948:71`

### 📌FHIR_SERVER_AUTH_TYPE
Authorization type for the FHIR server endpoint. Currently supported values are `NONE` and `BASIC` (all capital). If set to `BASIC`, a username and password env variables **MUST** also be set.

Example in ENV file:  
`FHIR_SERVER_AUTH_TYPE=NONE`

### 📌FHIR_SERVER_UN
If `FHIR_SERVER_AUTH_TYPE=BASIC`, this variable must hold the user name.

Example in ENV file:  
`FHIR_SERVER_UN=some_user`

### 📌FHIR_SERVER_PW
If `FHIR_SERVER_AUTH_TYPE=BASIC`, this variable must hold the password.

Example in ENV file:  
`FHIR_SERVER_PW=passw@rd`

**Note**: If you don't want to hard code the password in the env file you may set this as a system or user level environment variable and omit it from the `.env` file entirely. Same goes for `FHIR_SERVER_UN`.

### 📌FHIR_SERVER_TIMEOUT
Timeout (in milliseconds) for FHIR server API calls. Default is 30000.

Example in ENV file:  
`FHIR_SERVER_TIMEOUT=60000`

### 📌MOCKING_KIT
For developers only. This flag adds a "mock" test kit that makes it easy to test and debug the integration between the web UI and the engine during test runs. When set to "true" (string, lowercase), the Certificator homepage will have a "Mock Kit" entry added to the test kit drop-down list.

Example in ENV file:  
`MOCKING_KIT=true`

### 📌RESOURCE_SAMPLE_SIZE
When sampling random resources from the FHIR server, this determines how many resources are collected. When this parameter is not set, the default of 1000 resources is used. 

When performing tests & development work, it may be helpful to set this manually to a lower number to reduce the amount of time the sampling process takes to complete.

Example in ENV file:  
`RESOURCE_SAMPLE_SIZE=50`

### 📌STRONG_IDENTIFIER_SYSTEMS
A comma delimited list of canonical URL *prefixes* that will be regarded as **"strong"** identifier namespaces, meaning they are in *full control of the organization being certified*, and *should* be guaranteed to act as a **globally unique identifier** for a resource instance accross servers and organizations.  
The content of this environment variable is accessible from within mappings using the `$strongIdentifierSystems` parameter. The parameter `$strongIdentifierSystems` is an array of strings, where each string is one of the comma separated values from the env variables.  
If the env variable is missing or empty, `$strongIdentifierSystems` will be an empty array (`[]`).

### 📌ENABLE_FHIR_TRACING
**For developers and debugging only.** When set to `true` (string, lowercase), enables comprehensive tracing of all FHIR server interactions performed by the certificator. All calls to `$http`, `$search`, `$resolve`, `$literal`, and `$searchSingle` functions will be logged to a `fhir-trace.log` file in the installation directory.

Each trace entry is output as a JSON object with `functionName`, `timestamp`, and `params` properties, followed by a trailing comma. To convert the trace file to valid JSON, remove the comment lines, remove the last comma, and wrap all entries in square brackets `[...]`.

**Example trace output format:**
```
// FHIR Trace Log Started at 2025-01-01T10:00:00.000Z (Run: 20250101-100000)
// To convert to valid JSON: remove this comment, remove the last comma, and wrap all entries in [ ]
{"functionName":"$search","timestamp":"2025-01-01T10:00:00.123Z","params":{"resourceType":"Patient","params":"name=John"}},
{"functionName":"$resolve","timestamp":"2025-01-01T10:00:01.456Z","params":{"reference":"Patient/123"}},
```

**Performance Impact**: When enabled, this feature adds logging overhead to every FHIR operation. When disabled (default), there is zero performance impact as the original functions are used without any wrappers.

**File Management**: 
- The trace log file is automatically reset at the start of each kit run to prevent unlimited file growth
- Each trace log is tagged with the kit run timestamp for identification
- When a kit run is stashed (moved to `runs/` folder), the corresponding trace log is automatically copied to that run's folder if it belongs to that run

Example in ENV file:  
`ENABLE_FHIR_TRACING=true`

**Default**: `false` (disabled)

### 🔧SESSION_CACHE_IMPLEMENTATION & SESSION_CACHE_DURATION
These two parameters are automatically added to the `.env` file and should not be touched. They control how the HL7 Validator Wrapper behaves regarding validation sessions. These **must** be their exact values:
```
SESSION_CACHE_IMPLEMENTATION=PassiveExpiringSessionCache
SESSION_CACHE_DURATION=-1
```

### 📌VALIDATOR_INSTANCES (Optional / Power Users Only)
Controls how many parallel HL7 FHIR validator session instances are started. By default the Certificator automatically chooses the smaller of (number of CPU cores, 4). Setting this variable lets you explicitly request a number of instances (between 1 and 4). Any value above the limits, non‑numeric values, zero or negatives are ignored and the automatic default is used instead.

Reasons you might set this:
- Faster validator warmup times during development and testing
- Limiting memory / CPU usage in constrained environments (e.g. CI, containers)

Behavior:
- Omit variable: auto = min(cpuCount, 4)
- Set variable: clamped to [1..4] and not above cpuCount
- Invalid value (e.g. text, 0, negative): falls back to auto

Example in ENV file:
`VALIDATOR_INSTANCES=2`

Default: (not set) automatic selection.

Note: This variable is intentionally NOT added by the installer generated `.env` file and is not required for normal operation.