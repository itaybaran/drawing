# Building Certificator: Regular vs Frozen Builds

This document explains how to produce two kinds of executables:

1. Regular build (current kits topology + current code)
2. Frozen build (kits topology taken from an earlier git tag while using the CURRENT code, maps, charts, actions)

---
## 1. Terminology

| Term | Meaning |
|------|---------|
| Kits Topology | The hierarchical structure & contents of the `kits/` directory (all `index.yaml` plus child folder layout and `actions` references). |
| Frozen Kits | A snapshot of the kits topology taken from a specific git tag/commit and used while building a newer app version. |
| Actions | YAML files in `actions/` defining action metadata + mapping name. |
| Mapping Files | All artefacts in `maps/` (primary and helper map scripts). Actions reference an entry via `mapping`, but non-referenced helper maps are still bundled to allow maps calling other maps. |
| Charts | JSONata-based report chart expressions compiled ahead of time. |

The goal of a frozen build is to lock the kits topology (so certification milestones are reproducible) while allowing the executable to contain updated logic, mappings and charts.

---
## 2. Validations Enforced During Builds

Both regular and frozen builds run the same integrity validations:
- Duplicate action IDs are rejected.
- Each action's mapping file must exist (`maps/<mapping>.txt|json` or file without extension).
- Every action ID referenced in any kit YAML must be defined.
- Orphan actions (defined but unused) are only reported (not fatal).

---
## 3. Regular Build Workflow

### Command
```
npm run build:exe
```

### What Happens
1. `clean` – removes previous build artefacts.
2. `build:kits` – builds `kits.json` from the CURRENT working copy `actions/` + `kits/`.
3. `prebuild-charts` – bundles all chart expressions.
4. `build:ts`, `build:ui`, `build:report` – compiles TypeScript and web/report assets.
5. SEA packaging steps (`build:sea`, `create-sea-config`, `create-blob`) – produce single executable artefacts.
6. `copy-node-exe` & `inject_blob` – inject the application blob into a copy of the Node runtime.
7. `write_exe_meta.bat` – imprints metadata & version (from `package.json#version`).
8. Final executable copied to: `dist/sea/certificator.exe`.

### Result
- Uses the latest kits topology as currently in your working tree.
- Executable version string = the **unchanged** `package.json` version (e.g. `2.3.0`).

### Output Locations
| Path | Purpose |
|------|---------|
| `dist/sea/certificator.exe` | Final distributable executable. |
| `kits.json` | Generated kits manifest used at runtime. |

---
## 4. Frozen Build Workflow

### When To Use
You want to release a new executable (new code/maps/charts) while preserving a previously released kits topology (e.g. a hotfix released during the same certification milestone stage).

### Command Options
Run the build orchestrator directly:
```
node scripts/frozenExeBuild.js --kits-tag <tag-or-commit>
```
Or via the npm convenience script (pass the tag as positional arg):
```
npm run build:exe:frozen v2.2.1
```
(Equivalent to: `node scripts/frozenExeBuild.js --kits-tag v2.2.1`)

### Provenance & Version Handling (Updated)
The frozen build NO LONGER mutates `package.json`. Instead it:
1. Requires a clean working tree and committed `package.json`.
2. Builds using the committed version (e.g. `2.3.0`).
3. Computes a frozen version label: `<committedVersion>+kits(<kitsTag>)`.
4. Writes `build-info.json` containing: `{ buildType, kitsTag, commitSha, baseVersion, frozenVersion, timestampUtc }`.
5. Post-processes the produced executable to patch metadata to the frozen version string (so the file properties show the provenance label).

Result: Source-controlled version remains authoritative; the binary carries immutable provenance without uncommitted changes.

### What Happens Internally
1. `freezeKitsFromTag.js` materializes ONLY the `kits/` directory from the specified git tag (using `git show / ls-tree`) into a temporary folder (no working tree changes).
2. `buildKitsJson.js` runs using that frozen kits directory + CURRENT `actions/` (and validates references).
3. The orchestrator patches `package.json` version temporarily to:
   ```
   <baseVersion>+kits(<kitsTag>)
   ```
   Example: `2.3.0+kits(v2.2.1)`
4. Executes the normal `build:exe` pipeline (now embedding the frozen kits.json and labeled version).
5. Restores the original `package.json` version after completion (success or failure).

### Result
- `kits.json` reflects the kits topology exactly as in the supplied tag.
- All other assets (actions, mappings, charts, code) are from the current working copy.
- Executable version string includes provenance suffix (e.g. `2.3.0+kits(v2.2.1)`).

### Output Locations (same as regular build)
| Path | Purpose |
|------|---------|
| `dist/sea/certificator.exe` | Final frozen build executable. |
| `kits.json` | Generated with frozen kits topology. |

---
## 5. Pre-Build Checklist

| Item | Regular Build | Frozen Build |
|------|---------------|--------------|
| Working tree clean (recommended) | Yes | Yes (strongly) |
| Tag exists | n/a | Required (`git tag -l <tag>`) |
| Actions reference validation | Auto | Auto |
| Mapping files existence | Auto | Auto |
| Decide base version bump | Commit beforehand | Commit beforehand |

---
## 6. Versioning Pattern Enforcement
Frozen builds enforce the pattern:
```
<semver>[optional-pre-release]+kits(<tag>)
```
Examples:
- `2.2.1+kits(v2.2.1)`
- `2.3.0-rc.1+kits(v2.2.1)`

The suffix clearly records the kits topology source. The original `package.json` is restored after the build, so normal development versioning is unaffected.

---
## 7. Common Scenarios

### A. Ship a hotfix with unchanged kits topology
```
# Tag of last certified kits topology: v2.2.1
node scripts/frozenExeBuild.js --kits-tag v2.2.1
```
Result version label in exe metadata: `2.2.2+kits(v2.2.1)` (assuming package.json had 2.2.2 committed).

### B. Prepare next minor release but keep earlier kits until new topology is certified
```
node scripts/frozenExeBuild.js --kits-tag v2.2.1 (package.json already at 2.3.0)
```
Result version label in exe metadata: `2.3.0+kits(v2.2.1)`.

### C. Reproduce an older certified build exactly
Checkout the commit whose code you want, then:
```
node scripts/frozenExeBuild.js --kits-tag v2.2.1 (package.json already at 2.2.1)
```
Result version label in exe metadata: `2.2.1+kits(v2.2.1)` (clarifies provenance vs plain `2.2.1`).

---
## 8. Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| `Tag 'X' not found` | Typo or tag not pushed | `git fetch --tags` then retry |
| `ERROR: Kits reference undefined action ids` | Kits tag expects an action removed later | Reintroduce action or pick newer tag with aligned actions |
| Mapping file error | Action mapping file renamed/removed | Restore or update mapping file | 
| Version pattern error | Custom base version malformed | Use valid semver (e.g. 2.3.0 or 2.3.0-rc.1) |

---
## 9. Frequently Asked Questions

**Q: Does a frozen build lock action implementations?**  
No. Only kits topology is frozen. Action YAML + mappings come from current code.

**Q: Can I freeze against a commit hash instead of a tag?**  
Yes. Supply the commit SHA where a valid `kits/` lived.

**Q: Why restore `package.json`?**  
To avoid polluting git history with transient provenance suffixes while still embedding them inside the built executable.

**Q: Where do I see the frozen version once built?**  
Check `dist/sea/certificator.exe` file properties (version info).

---
## 10. Summary
Choose a regular build for day-to-day development and when kits changes should go live. Choose a frozen build to release updated code while ensuring kit topology stability. The `+kits(<tag>)` suffix embeds provenance, enabling traceability and reproducibility.

---
## 11. CI Guidance (TODO)

Integrate both build modes in CI to ensure reproducibility and early detection of integrity regressions.

### 11.1 Jobs Overview
| Job | Trigger | Purpose |
|-----|---------|---------|
| regular-build | push / PR | Validate current code + kits | 
| frozen-build | manual (workflow_dispatch) | Produce release exe with frozen kits |

### 11.2 Regular Build (GitHub Actions Sample)
```yaml
name: regular-build
on: [push, pull_request]
jobs:
   build:
      runs-on: windows-latest
      steps:
         - uses: actions/checkout@v4
         - uses: actions/setup-node@v4
            with:
               node-version: 20
         - run: npm ci
         - run: npm run build:exe
         - uses: actions/upload-artifact@v4
            with:
               name: certificator-regular-${{ github.sha }}
               path: dist/sea/certificator.exe
```

### 11.3 Frozen Build (Parameterized)
```yaml
name: frozen-build
on:
   workflow_dispatch:
      inputs:
         kits_tag:
            description: Git tag/commit providing kits topology
            required: true
      # base version now must already be committed in package.json
jobs:
   frozen:
      runs-on: windows-latest
      steps:
         - uses: actions/checkout@v4
            with:
               fetch-depth: 0
         - uses: actions/setup-node@v4
            with:
               node-version: 20
         - run: npm ci
         - name: Frozen build
            run: |
                node scripts/frozenExeBuild.js --kits-tag ${{ inputs.kits_tag }}
         - name: Verify version suffix
            shell: bash
            run: strings dist/sea/certificator.exe | grep -E "+kits\(" || (echo 'Missing kits suffix' && exit 1)
         - uses: actions/upload-artifact@v4
            with:
               name: certificator-frozen-${{ inputs.kits_tag }}
               path: dist/sea/certificator.exe
```

### 11.4 Suggested CI Assertions
| Check | Mode | Rationale |
|-------|------|-----------|
| kits suffix present in version (frozen) | frozen | Guarantees provenance | 
| build script exit code non-zero on missing actions/mappings | both | Prevents runtime errors |
| Tag existence (git rev-parse) | frozen | Fast fail if mistyped tag |
| Working tree cleanliness (optional) | frozen | Avoid mixing uncommitted changes |

### 11.5 Release Workflow Suggestion
1. Tag kits topology when certified (e.g. `v2.2.1`).
2. Develop new code; when releasing, run frozen-build with that kits tag.
3. Publish artifact named with full version (`2.3.0+kits(v2.2.1)`).
4. Later certify new kits, create new kits tag, repeat.

### 11.6 Local Preflight (Optional)
Add a script that:
1. Verifies tag exists.
2. Runs `node scripts/freezeKitsFromTag.js <tag>` then immediately discards output (dry run) to confirm integrity.
3. Emits a summary table of referenced vs defined actions.

---
*End of document.*
