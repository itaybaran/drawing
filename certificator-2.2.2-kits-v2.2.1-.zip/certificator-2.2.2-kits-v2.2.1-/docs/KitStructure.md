# Kit Structure Documentation

This document explains how the `kits.json` file is generated from the YAML files in the `actions` and `kits` folders.

## Overview

The `kits.json` file is now automatically generated from individual YAML files using the `buildKitsJson.js` script. This approach allows for better organization and maintainability of the kit definitions, and minimizes merge conflicts.
The switch to YAML also allows for comments (the `#` character marks the beginning of a comment in YAML).

## File Structure

### Actions
Actions are defined in individual YAML files in the `actions/` folder. Each file contains a single action definition with the following structure:

```yaml
id: action-id
description: Action description
mapping: mappingId
parameters:  # Optional
  - paramName: paramValue
```

### Kits
Kits are organized hierarchically in the `kits/` folder. Each kit has its own folder containing an `index.yaml` file:

```yaml
id: kit-id
name: Kit Name
description: Kit description
children:
  - group-1
  - group-2
```

### Groups and sub-groups
Each kit's direct children are considered "groups", and they also have their own folder with an `index.yaml` file:

```yaml
id: group-id
name: Group Name
children:
  - sub-group-1
  - sub-group-2
```

The same structure applies to the sub groups (group's children):

```yaml
id: sub-group-id
name: Sub-group Name
children:
  - test-1
  - test-2
```

### Tests
The children of a sub-group are individual tests. Tests also have an `index.yaml` file:

```yaml
id: test-id
name: Test Name
description: Test description
details: Additional details relevant for this test
actions:
  - action-1
  - action-2
```

Each action id must correspond to an action defined in the `actions` folder (see [Actions](#actions) section).

**Important**: When using special characters in any field values, always quote the entire value:
```yaml
# ✅ Correct - quoted values with special characters
name: "Resource references"
description: "Content-Type: application/fhir+json validation"
details: "% of practitioners w/o any roles"

# ✅ Correct - multiline content using block scalar
details: |
  This is a longer description that spans
  multiple lines and may contain URLs like
  https://hl7.org/fhir/R4/datatypes.html
```

## Build Process

After making changes in the yaml files it is recommended to check that the process successfullly regenerates the `kits.json` file from the YAML sources without errors:

```bash
npm run build:kits
```

The script will:
1. Load all action YAML files from the `actions/` folder
2. Recursively load all kit definitions from the `kits/` folder and sub-folders
3. Generate the complete `kits.json` file
4. Validate the structure and report any issues

If any errors are reported, fix the issues and try to generate again.

## Integration with Build Process

The `build:kits` script is automatically run as part of the main build process:

```bash
npm run build  # This now includes building kits.json
```

And is also trigerred as part of the `start` script:
```bash
npm start
```

### Common YAML Formatting Issues

When creating or editing YAML files, be aware of these common formatting issues that can cause parsing errors:

#### 1. Special Characters in Values
**Problem**: Unquoted values containing special YAML characters like `:`, `%`, `=`, `@`, etc.
```yaml
# ❌ Wrong - will cause parsing error
details: Content-Type: application/fhir+json
details: % of practitioners w/o any roles
```

**Solution**: Quote values containing special characters:
```yaml
# ✅ Correct
details: "Content-Type: application/fhir+json"
details: "% of practitioners w/o any roles"
```

#### 2. Multiline Text Content
**Problem**: Multiline text without proper YAML formatting can cause "multiline key may not be an implicit key" errors.
```yaml
# ❌ Wrong - will cause parsing error
details: First line of text
Second line of text
Third line of text
```

**Solution**: Use YAML block scalar syntax with `|` for multiline content:
```yaml
# ✅ Correct
details: |
  First line of text
  Second line of text
  Third line of text
```

#### 3. Trailing Colons in Names
**Problem**: Trailing colons in field values can be interpreted as mapping indicators.
```yaml
# ❌ Wrong - will cause parsing error
name: Resource references:
```

**Solution**: Quote values with trailing colons or remove the colon:
```yaml
# ✅ Correct options
name: "Resource references:"
# or
name: Resource references
```

#### 4. URLs and Complex Strings
**Problem**: URLs and strings with special characters may need quoting.
```yaml
# ❌ Potentially problematic
details: Check meta.security.system = http://example.com/path
```

**Solution**: Quote complex strings:
```yaml
# ✅ Correct
details: "Check meta.security.system = http://example.com/path"
```

### YAML Best Practices

1. **Always quote values** that contain special characters: `:`, `%`, `=`, `@`, `#`, `|`, `>`, `{`, `}`, `[`, `]`
2. **Use block scalar syntax** (`|` or `>`) for multiline content
3. **Validate YAML syntax** using online validators or IDE plugins before committing
4. **Be consistent** with indentation (use 2 spaces)
5. **Test the build** after making changes: `npm run build:kits`

### Troubleshooting

If you encounter YAML parsing errors:
1. Check the error message for the specific line and column
2. Look for unquoted special characters (`:`, `%`, `=`, etc.)
3. Ensure multiline content uses block scalar syntax (`|`)
4. Validate your YAML syntax using an online YAML validator
5. Run `npm run build:kits` to test your changes

## Notes

- The script automatically sorts actions by ID for consistency
- Kit hierarchy is preserved in the generated JSON

