# Chart Expressions - Developer Guide

The chart expressions system provides a modular approach to generating charts and tables in the certificator reports. Individual JSONata expressions have been extracted from the monolithic `helpers/expressions.ts` file to enable independent development and reduce merge conflicts.

## Architecture Overview

### How It Works
1. **Individual Chart Files**: Each `.jsonata` file in `charts/` contains a single chart expression
2. **Pre-build Compilation**: The `scripts/prebuild-charts.js` script validates syntax and compiles all expressions into `src/helpers/chartExpressions.json` as an ordered array
3. **Runtime Evaluation**: The main expression uses `$chartExpressions.$eval($, $$)` to execute each chart expression with shared context and the root input
4. **Order Preservation**: Charts are rendered in the order specified by `charts/.index` (a simple text file listing chart names without extensions)

### File Locations
- **Chart expressions**: `charts/*.jsonata`
- **Chart index**: `charts/.index`
- **Pre-build script**: `scripts/prebuild-charts.js`
- **Generated output**: `src/helpers/chartExpressions.json` (gitignored)
- **Main expression**: `src/helpers/reportDataProvider.ts`

### Shared Context
All chart expressions have access to shared variables defined in the main expression:
- `$kitName` - Kit name from configuration
- `$flatKit` - Flattened kit structure for test metadata lookups
- `$getTestMetadata($testId)` - Function to get test metadata by ID
- `$runSummary` - Run summary data (used by status pie chart)
- All bound variables: `$readIoFile`, `$certificatorVersion`, `$sampleSize`, etc.

## Adding a New Chart

1. **Create the JSONata file**: Add a new `.jsonata` file in `charts/`
   ```jsonata
   (
     $myData := $readIoFile('myDataFile.json');
     $exists($myData) ? {
       'id': 'my-chart-id',
       'title': 'My Chart Title',
       'type': 'pie', // or 'table', 'bar', 'line'
       'data': [/* your data transformation */]
     }
   )
   ```

2. **Add to index file**: Update `charts/.index` to include your chart in the desired position
   ```
   existingChart
   myNewChart
   anotherChart
   ```

3. **Test syntax**: Run `npm run prebuild-charts` to validate your JSONata syntax

4. **Build and test**: Run `npm run build` to compile and test the complete system

## Editing Existing Charts

1. **Find the chart file**: Locate the `.jsonata` file in `charts/` for your chart
2. **Edit the expression**: Modify the JSONata expression as needed
3. **Validate syntax**: Run `npm run prebuild-charts` to check for syntax errors
4. **Test changes**: Build and run the application to verify your changes

## Chart Structure Guidelines

### Conditional Charts
Most charts should include existence checks:
```jsonata
(
  $data := $readIoFile('dataFile.json');
  $exists($data) ? {
    'id': 'chart-id',
    'title': 'Chart Title',
    'type': 'pie',
    'data': [/* transformation */]
  }
)
```

### Chart Types
- **Table**: Use `'type': 'table'` with `columns` and `data` arrays
- **Pie Chart**: Use `'type': 'pie'` with `data` array of `{label, value}` objects
- **Bar Chart**: Use `'type': 'bar'` with `data` array of `{label, value}` objects  
- **Line Chart**: Use `'type': 'line'` with `data` array of `{label, value}` objects

### Expression Wrapping
All chart expressions that are comprised of several expressions separated by a semicolon (`;`) must be wrapped in parentheses to form valid JSONata block expressions.

### Differences from mapping expressions
Mapping expressions used as actions in certification tests have extended syntax (a superset of the JSONata syntax). For example, the single line comment syntax (//) and the $http() function. This is because they are FUME expressions and need to interact with the FHIR server. 

Chart expressions are *native JSONata expressions*, where only multiline-style comments (`/* comment */`) are supported, and only the native JSONata function set, with the addition of `$readIoFile()` (used for reading data files generated during the test run).

## Build System Integration

### Pre-build Validation
- **Automatic**: Runs as part of `npm run build`
- **Manual**: Run `npm run prebuild-charts` to validate only chart expressions
- **Validation**: Checks JSONata syntax, index file integrity, and file existence
- **Output**: Generates `src/helpers/chartExpressions.json` (gitignored)

### Error Handling
- **Syntax Errors**: Build fails with specific file and error details
- **Missing Files**: Errors for files referenced in index but not found
- **Orphaned Files**: **Build fails** for files not referenced in index (enforces clean codebase)

## Best Practices

1. **Use descriptive IDs**: Chart IDs should be unique and descriptive
2. **Include test numbers**: Reference the test number in chart titles when applicable
3. **Handle missing data**: Always check `$exists()` before processing data files
4. **Keep expressions focused**: Each file should contain only one chart/table
5. **Document complex logic**: Add comments for complex data transformations
6. **Test thoroughly**: Validate both syntax and runtime behavior

## Troubleshooting

### Common Issues
- **Syntax Errors**: Check parentheses wrapping and JSONata syntax
- **Undefined Variables**: Ensure you're using shared variables correctly
- **Order Issues**: Verify your chart is listed in `charts/.index`
- **Missing Data**: Check that your data files exist and `$readIoFile()` calls are correct
- **Orphaned Files**: All `.jsonata` files must be referenced in the index - remove unused files or add them to `charts/.index`

### Debugging Tips
- Run `npm run prebuild-charts` to isolate syntax issues
- Use the browser developer tools to inspect generated chart data
- Check the main expression in `src/helpers/reportDataProvider.ts` for shared variable definitions
