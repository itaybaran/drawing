import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.resolve(path.dirname(fileURLToPath(import.meta.url)));
const htmlPath = path.join(__dirname, 'dist', 'index.html');

let html = fs.readFileSync(htmlPath, 'utf-8');

html = html.replace(/<script (.*?)src="(.+?\.js)"(.*?)><\/script>/g, (match, p1, src, p3) => {
  if (src.includes('/assets/')) {
    return `<script ${p1}src="${src}"${p3} inline></script>`;
  }
  return match;
});

html = html.replace(/<link (.*?)href="(.+?\.css)"(.*?)>/g, (match, p1, href, p3) => {
  if (href.includes('/assets/')) {
    return `<link ${p1}href="${href}"${p3} inline>`;
  }
  return match;
});

html = html.replace(
  /<link\s+([^>]*?)href=["']favicon\.ico["']([^>]*?)\/?>/g,
  (match, pre, post) => {
    return `<link ${pre}href="/report/dist/favicon.ico"${post} inline />`;
  }
);

html = html.replaceAll('/report/assets/', '/report/dist/assets/');

html = html.replaceAll(/<link[^>]+href=["'].*?favicon\.ico["'][^>]*?>/gi, '');

fs.writeFileSync(htmlPath, html);
console.log('✅ Patched dist/index.html with inline attributes.');
