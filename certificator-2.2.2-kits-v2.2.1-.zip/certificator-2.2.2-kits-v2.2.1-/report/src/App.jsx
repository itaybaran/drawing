import React from 'react';
import israel from '../public/Emblem_of_Israel.svg'
import fhir from '../public/icon-fhir-720.png'
import logo from '../public/logo.svg'
import flameInline from '../public/icon-fhir-48.png';
import Report from './components/Report'
import './App.css'
import { downloadExportedReport } from './exportReport';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      data: {}
    };
  }

  async componentDidMount() {
    const res = await fetch('/report/data.json');
    const data = await res.json()
    this.setState({
      loading: false,
      data
    })
  }

  render() {
    return (
      <>
        <div className="header">
          <img src={logo} className="logo" alt="Ministry of Health logo" />
          <div className="header-title">
            <div className="title title-text">Ministry of Health</div>
            <div className="title subtitle-text">FHIR<sup className="subtitle-r">®</sup> Certificator - Report</div>
          </div>
          <img src={fhir} className="logo" alt="FHIR logo" />
          <img src={israel} className="israel-logo" alt="Israel flag" />
        </div>
        <div style={{ marginBottom: '1rem' }}><button onClick={downloadExportedReport}>Export Report</button></div>
        <div className="card">
          {!this.state.loading &&
            <Report data={this.state.data}></Report>
          }
        </div>
        <p className="copyright-footer">
          © Copyright Ministry of Health Israel 2024. All Rights Reserved
          <br />HL7®, FHIR® and the FHIR <img src={flameInline} className="flameInline" alt="[FLAME SYMBOL]"></img>® flame design are the registered trademarks of Health Level Seven International and their use does not constitute endorsement by HL7.
        </p>
      </>
    )
  }
}

export default App;
