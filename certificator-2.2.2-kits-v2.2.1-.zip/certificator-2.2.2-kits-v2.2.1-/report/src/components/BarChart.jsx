/* eslint-disable react/prop-types */
import React from 'react';
import "./BarChart.css";
import { Bar } from 'react-chartjs-2';

class BarChart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      offset: Math.floor(Math.random() * 100)
    };
  }

  render() {
    return (
      <div className="bar-chart-report">
        <h2>{this.props.chart.title}</h2>
        <div className="bar-chart-js">
          <Bar className="bar-chart-js"
            options={{
              plugins: {
                autocolors: {
                  mode: 'dataset',
                  offset: this.state.offset
                },
                legend: {
                  display: false
                }
              }
            }
            }
            data={{
              labels: this.props.chart.data.map(element => element.label),
              datasets: [{
                data: this.props.chart.data.map(element => element.value),
                tension: 0.1,
                drawActiveElementsOnTop: false,
              }]
            }} />
        </div>
      </div>
    );
  }
}

export default BarChart;
