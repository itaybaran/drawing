/* eslint-disable react/prop-types */
import React from 'react';
import "./Report.css";
import Chart from "chart.js/auto";
import autocolorPlugin from 'chartjs-plugin-autocolors';
import PieChart from './PieChart'
import LineChart from './LineChart'
import TableChart from './TableChart';
import BarChart from './BarChart';
Chart.register(autocolorPlugin)

class Report extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
        {this.props.data.charts.map(chart => {
          // if data is not an array, wrap it
          if (!Array.isArray(chart.data)) {
            chart.data = [chart.data];
          }
          // we need to cleanup the data array so only objects (non-empty) are allowed. No nulls.
          // if after filtering nothing is left, data should be an empty array.
          chart.data = chart.data.filter(d => d && Object.keys(d).length > 0);
          if (chart.type === 'pie') {
            return <PieChart key={chart.id} chart={chart}></PieChart>
          }
          if (chart.type === 'line') {
            return <LineChart key={chart.id} chart={chart}></LineChart>
          }
          if (chart.type === 'table') {
            return <TableChart key={chart.id} chart={chart}></TableChart>
          }
          if (chart.type === 'bar') {
            return <BarChart key={chart.id} chart={chart}></BarChart>
          }
        }
        )}
      </div>
    );
  }
}

export default Report;