export async function downloadExportedReport() {
  try {
    const [htmlText, jsonData] = await Promise.all([
      fetch('/report/export.html').then(res => res.text()),
      fetch('/report/data.json').then(res => res.json())
    ]);

    const jsonStr = JSON.stringify(jsonData, null, 2);

    // Remove the Export Report button
    let modifiedHtml = htmlText;

    // Replace dynamic fetch with embedded data
    const target = '{const i=await(await fetch("/report/data.json")).json();this.setState({loading:!1,data:i})}';
    const replacement = `{const i=${jsonStr};this.setState({loading:false,data:i});};`;

    const firstIndex = modifiedHtml.indexOf(target);
    const secondIndex = modifiedHtml.indexOf(target, firstIndex + target.length);

    if (secondIndex !== -1) {
      modifiedHtml =
        modifiedHtml.slice(0, secondIndex) +
        replacement +
        modifiedHtml.slice(secondIndex + target.length);
    }

    modifiedHtml = modifiedHtml.replaceAll('Z.jsx("div",{style:{marginBottom:"1rem"},children:Z.jsx("button",{onClick:ox,children:"Export Report"})}),', '');

    // Extract fields from the chart with id "run-attributes"
const runAttributesChart = (jsonData.charts || []).find(c => c.id === 'run-attributes');

let kit, date, time, user, domain;

if (runAttributesChart?.data) {
  const lookup = Object.fromEntries(runAttributesChart.data.map(entry => [entry.key, entry.value]));

  kit = lookup['Kit Name'];
  date = lookup['Execution Date'];
  time = lookup['Execution Time'];
  user = lookup['User Name'];
  domain = lookup['User Domain'];
}

const safe = (str) => str?.replace(/[<>:"/\\|?*\n\r\t]+/g, '_') || 'Unknown';
const fallback = () => new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');

const filename = (kit && date && time && user && domain)
  ? `${safe(date)}_${safe(time)}_${safe(kit)}_${safe(domain)}_${safe(user)}.html`
  : `FHIR-Report-${fallback()}.html`;


    // Create and trigger download
    const blob = new Blob([modifiedHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  } catch (err) {
    alert('Export failed: ' + err.message);
    console.error(err);
  }
}
