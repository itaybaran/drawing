const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

/**
 * Builds kits.json from YAML files in the actions and kits folders
 *
 * This script regenerates the kits.json file by:
 * 1. Loading all action definitions from individual YAML files in the actions/ folder
 * 2. Recursively loading all kit definitions from the hierarchical kits/ folder structure
 * 3. Combining them into a single JSON structure matching the original format
 *
 * Usage: node scripts/buildKitsJson.js
 * Or: npm run build:kits
 */
class KitsJsonBuilder {
  constructor (opts = {}) {
    this.actionsDir = opts.actionsDir || path.join(__dirname, '..', 'actions');
    this.kitsDir = opts.kitsDir || path.join(__dirname, '..', 'kits');
    this.outputFile = opts.outputFile || path.join(__dirname, '..', 'kits.json');

    this.actions = [];
    this.kits = [];
    // Map action id -> relative file path (for diagnostics)
    this.actionIdToFile = new Map();
  }

  /**
   * Main build function
   */
  build () {
    console.log(`Building kits.json from YAML files (kits source: ${this.kitsDir})...`);

    // Load all actions
    this.loadActions();

    // Load all kits
    this.loadKits();

    // Validate: every referenced action id has a definition
    this.validateMissingActionReferences();

    // Validate: detect orphaned actions (action YAMLs not referenced by any kit)
    this.validateOrphanActions();

    // Generate the final JSON structure
    const result = {
      actions: this.actions,
      kits: this.kits
    };

    // Write to file
    fs.writeFileSync(this.outputFile, JSON.stringify(result, null, 2));

    console.log(`Generated kits.json with ${this.actions.length} actions and ${this.kits.length} kits`);
  }

  /**
   * Load all action YAML files from the actions directory
   */
  loadActions () {
    const actionFiles = fs.readdirSync(this.actionsDir).filter(file => file.endsWith('.yaml'));

    for (const file of actionFiles) {
      try {
        const filePath = path.join(this.actionsDir, file);
        const content = fs.readFileSync(filePath, 'utf8');
        const action = yaml.load(content);

        // Validate required fields
        if (!action.id || !action.description || !action.mapping) {
          console.warn(`Action ${file} is missing required fields (id, description, mapping)`);
          continue;
        }

        // Detect duplicate action ids early (fail build deterministically)
        if (this.actionIdToFile.has(action.id)) {
          const firstFile = this.actionIdToFile.get(action.id);
          console.error(`ERROR: Duplicate action id '${action.id}' defined in both '${firstFile}' and '${path.relative(path.join(__dirname, '..'), filePath)}'`);
          throw new Error(`Duplicate action id '${action.id}'`);
        }

        // Convert parameters array to object if it exists
        if (action.parameters && Array.isArray(action.parameters)) {
          const paramObj = {};
          action.parameters.forEach(param => {
            Object.assign(paramObj, param);
          });
          action.parameters = paramObj;
        }

        // Validate mapping file existence under maps/.
        // Accept either .txt or .json and also allow file without extension if present.
        const mapsDir = path.join(__dirname, '..', 'maps');
        const mappingBase = action.mapping; // e.g., 'doExtractIds'
        const possibleFiles = [
          `${mappingBase}.txt`,
          `${mappingBase}.TXT`,
          `${mappingBase}.json`,
          `${mappingBase}.JSON`,
          mappingBase // file exactly named as mapping (e.g., isGetContentTypeOK without extension)
        ];
        const mappingExists = possibleFiles.some(f => fs.existsSync(path.join(mapsDir, f)));
        if (!mappingExists) {
          console.error(`ERROR: Mapping file for action '${action.id}' not found. Tried: ${possibleFiles.join(', ')}`);
          throw new Error(`Missing mapping file for action '${action.id}'`);
        }

        this.actions.push(action);
        // Keep source file for diagnostics
        this.actionIdToFile.set(action.id, path.relative(path.join(__dirname, '..'), filePath));
      } catch (error) {
        console.error(`Error loading action ${file}:`, error.message);
      }
    }

    // Sort actions by id for consistency
    this.actions.sort((a, b) => a.id.localeCompare(b.id));
  }

  /**
   * Load all kit YAML files from the kits directory recursively
   */
  loadKits () {
    const kitDirs = fs.readdirSync(this.kitsDir).filter(item => {
      return fs.statSync(path.join(this.kitsDir, item)).isDirectory();
    });

    for (const kitDir of kitDirs) {
      // Don't catch errors here - let them bubble up to fail the build
      const kit = this.loadKitRecursive(path.join(this.kitsDir, kitDir));
      if (kit) {
        this.kits.push(kit);
      }
    }
  }

  /**
   * Recursively load a kit and its children from a directory
   */
  loadKitRecursive (kitPath) {
    const indexFile = path.join(kitPath, 'index.yaml');

    if (!fs.existsSync(indexFile)) {
      console.warn(`No index.yaml found in ${kitPath}`);
      return null;
    }

    try {
      const content = fs.readFileSync(indexFile, 'utf8');

      // Try to load with safe option to avoid issues with multiline strings
      const kit = yaml.load(content, {
        schema: yaml.SAFE_SCHEMA,
        onWarning: (warning) => {
          console.warn(`YAML warning in ${kitPath}: ${warning.message}`);
        }
      });

      // Validate required fields
      if (!kit.id) {
        console.warn(`Kit in ${kitPath} is missing required id field`);
        return null;
      }

      // Load children if they exist
      if (kit.children && Array.isArray(kit.children)) {
        const loadedChildren = [];

        for (const childId of kit.children) {
          const childPath = path.join(kitPath, childId);

          if (fs.existsSync(childPath) && fs.statSync(childPath).isDirectory()) {
            const child = this.loadKitRecursive(childPath);
            if (child) {
              loadedChildren.push(child);
            }
          } else {
            console.warn(`Child ${childId} not found in ${kitPath}`);
          }
        }

        kit.children = loadedChildren;
      }

      return kit;
    } catch (error) {
      // Log detailed error information for debugging
      console.error(`Error parsing YAML in ${kitPath}: ${error.message}`);
      console.error(error.stack);

      // fail the build on critical errors
      throw new Error(`Critical error while parsing YAML in ${kitPath}. Aborting build.`);
    }
  }

  /**
   * Validate that every action YAML is referenced by at least one kit file under an 'actions' array.
   * If orphaned actions are found, fail the build with a clear error message listing them.
   */
  validateOrphanActions () {
    // Collect all action ids referenced anywhere in kits directory structure
    const referenced = this.collectReferencedActionIdsFromKits();

    const allActionIds = new Set(this.actions.map(a => a.id));
    const orphanIds = [...allActionIds].filter(id => !referenced.has(id));

    if (orphanIds.length > 0) {
      console.error('Found orphaned action YAML files (not referenced by any kit actions list):');
      orphanIds
        .sort()
        .forEach(id => {
          const src = this.actionIdToFile.get(id) || '(unknown file)';
          console.error(` - ${id}  <- ${src}`);
        });
      console.error(`Total orphaned actions: ${orphanIds.length}`);
    }
  }

  /**
   * Scan all YAML files under kits/ and collect action ids referenced in 'actions' arrays
   * Returns a Set of action id strings
   */
  collectReferencedActionIdsFromKits () {
    const referenced = new Set();

    const walk = (dir) => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          walk(full);
        } else if (entry.isFile() && (entry.name.endsWith('.yaml') || entry.name.endsWith('.yml'))) {
          try {
            const content = fs.readFileSync(full, 'utf8');
            const doc = yaml.load(content, { schema: yaml.SAFE_SCHEMA });
            if (doc && Array.isArray(doc.actions)) {
              for (const actionRef of doc.actions) {
                if (typeof actionRef === 'string' && actionRef.trim()) {
                  referenced.add(actionRef.trim());
                }
              }
            }
          } catch (e) {
            console.warn(`Warning: failed to parse ${path.relative(path.join(__dirname, '..'), full)}: ${e.message}`);
          }
        }
      }
    };

    if (fs.existsSync(this.kitsDir)) {
      walk(this.kitsDir);
    }

    return referenced;
  }

  /**
   * Validate that every action id referenced in any kit file exists among loaded actions.
   * Fails the build if any are missing.
   */
  validateMissingActionReferences () {
    const referenced = this.collectReferencedActionIdsFromKits();
    const defined = new Set(this.actions.map(a => a.id));
    const missing = [...referenced].filter(id => !defined.has(id));
    if (missing.length) {
      console.error('ERROR: Kits reference undefined action ids:');
      missing.sort().forEach(id => console.error(' - ' + id));
      throw new Error(`Missing ${missing.length} action definition(s)`);
    }
  }
}

// Main execution
if (require.main === module) {
  try {
    const builder = new KitsJsonBuilder();
    builder.build();
  } catch (error) {
    console.error('Failed to build kits.json:', error.message);
    process.exit(1);
  }
}

module.exports = KitsJsonBuilder;
