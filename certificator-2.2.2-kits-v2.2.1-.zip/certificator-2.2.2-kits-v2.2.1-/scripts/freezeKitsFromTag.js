#!/usr/bin/env node
/**
 * Build kits.json using the kits/ folder content from a given git tag while using
 * the current working copy for everything else (actions/, maps/, code, etc.).
 *
 * Usage: node scripts/freezeKitsFromTag.js v2.2.1
 *  - Requires: git available on PATH
 *  - Does NOT modify the working tree (uses git show to read file contents)
 *  - Writes kits.json (overwrites) in repo root based on tagged kits topology.
 *
 * Rationale: Allows releasing a new application version that locks kit topology
 * to a previously tagged state while incorporating updated code/maps/charts.
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const KitsJsonBuilder = require('./buildKitsJson.js');

function run (cmd) {
  return execSync(cmd, { stdio: ['ignore', 'pipe', 'inherit'] }).toString('utf8');
}

function assertTagExists (tag) {
  try {
    run(`git rev-parse --verify ${tag}`);
  } catch (e) {
    console.error(`ERROR: Tag '${tag}' not found.`);
    process.exit(1);
  }
}

function listKitsFilesAtTag (tag) {
  // List all files under kits/ at the tag
  const out = run(`git ls-tree -r --name-only ${tag} -- kits`);
  return out.split(/\r?\n/).filter(Boolean);
}

function materializeKitsAtTag (tag) {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kits-freeze-'));
  const kitsRoot = path.join(tmpDir, 'kits');
  fs.mkdirSync(kitsRoot);

  const files = listKitsFilesAtTag(tag);
  if (files.length === 0) {
    console.error(`ERROR: Tag '${tag}' contains no kits/ directory contents.`);
    process.exit(1);
  }

  for (const rel of files) {
    const content = run(`git show ${tag}:${rel}`);
    const destPath = path.join(tmpDir, rel);
    const destDir = path.dirname(destPath);
    fs.mkdirSync(destDir, { recursive: true });
    fs.writeFileSync(destPath, content, 'utf8');
  }
  return kitsRoot;
}

function main () {
  const tag = process.argv[2];
  if (!tag) {
    console.error('Usage: node scripts/freezeKitsFromTag.js <git-tag>');
    process.exit(1);
  }

  assertTagExists(tag);
  console.log(`Freezing kits topology from tag: ${tag}`);

  const kitsDir = materializeKitsAtTag(tag);

  // Build using current actions dir but tagged kits directory
  const builder = new KitsJsonBuilder({ kitsDir });
  builder.build();

  console.log('kits.json successfully built using kits/ from tag:', tag);
}

if (require.main === module) {
  try {
    main();
  } catch (err) {
    console.error('Failed to freeze kits from tag:', err.message);
    process.exit(1);
  }
}
