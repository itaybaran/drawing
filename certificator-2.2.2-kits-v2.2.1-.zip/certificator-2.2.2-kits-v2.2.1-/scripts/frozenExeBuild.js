#!/usr/bin/env node
/**
 * Frozen exe build (strict provenance):
 * 1. Require --kits-tag <tag>
 * 2. Ensure working tree clean & package.json unchanged (committed base version)
 * 3. Generate kits.json from tagged kits folder
 * 4. Compute frozen version = <package.json version>+kits(<kitsTag>) WITHOUT modifying package.json
 * 5. Build exe with original version embedded (unchanged) then patch exe metadata & embed build-info.json provenance
 * 6. Output: dist/sea/certificator.exe plus build-info.json (with commit SHA, kitsTag, frozenVersion)
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

function run (cmd) {
  return execSync(cmd, { stdio: 'inherit' });
}

function parseArgs () {
  const args = process.argv.slice(2);
  const res = {};
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '--kits-tag') { res.kitsTag = args[++i]; } else if (!res.kitsTag && !a.startsWith('--')) { res.kitsTag = a; }
  }
  return res;
}

function get (cmd) { return execSync(cmd, { stdio: ['ignore', 'pipe', 'ignore'] }).toString('utf8').trim(); }

function ensureCleanWorkingTree () {
  const status = get('git status --porcelain');
  if (status) {
    console.error('ERROR: Working tree not clean. Commit or stash changes before frozen build.');
    process.exit(1);
  }
}

function ensurePackageJsonCommitted (pkgPath) {
  const rel = path.relative(process.cwd(), pkgPath).replace(/\\/g, '/');
  const diff = get(`git diff --name-only ${rel}`);
  if (diff) {
    console.error('ERROR: package.json has uncommitted changes. Commit before frozen build.');
    process.exit(1);
  }
}

function validateBaseVersion (v) {
  const ok = /^\d+\.\d+\.\d+(?:[-][0-9A-Za-z.+]+)?$/.test(v);
  if (!ok) {
    console.error('ERROR: package.json version not valid semver (pre-release allowed) ->', v);
    process.exit(1);
  }
}

function main () {
  const { kitsTag } = parseArgs();
  if (!kitsTag) {
    console.error('Usage: node scripts/frozenExeBuild.js --kits-tag <tag>');
    process.exit(1);
  }

  const pkgPath = path.join(__dirname, '..', 'package.json');
  const originalPkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  const originalVersion = originalPkg.version;
  validateBaseVersion(originalVersion);

  ensureCleanWorkingTree();
  ensurePackageJsonCommitted(pkgPath);

  try {
    console.log('[freeze] Step 1/5: Build kits.json from tag', kitsTag);
    run(`node scripts/freezeKitsFromTag.js ${kitsTag}`);

    console.log('[freeze] Step 2/5: Compute frozen version (no package.json mutation)');
    const frozenVersion = `${originalVersion}+kits(${kitsTag})`;
    console.log('[freeze] Frozen version ->', frozenVersion);

    console.log('[freeze] Step 3/5: Building executable (base version remains)', originalVersion);
    run('npm run build:exe');

    console.log('[freeze] Step 4/5: Write build-info.json provenance');
    const commitSha = get('git rev-parse HEAD');
    const info = {
      buildType: 'frozen',
      kitsTag,
      commitSha,
      baseVersion: originalVersion,
      frozenVersion,
      timestampUtc: new Date().toISOString()
    };
    fs.writeFileSync(path.join(__dirname, '..', 'build-info.json'), JSON.stringify(info, null, 2) + '\n');
    console.log('[freeze] build-info.json written');

    console.log('[freeze] Step 5/5: Patch exe metadata to frozen version');
    // Re-run verpatch with frozenVersion (keeping original digital lineage) by invoking write_exe_meta then an extra patch
    // Simpler: replicate write_exe_meta logic inline with overridden version
    const metaPatch = `@echo off\nSET BUILD_VERSION=${frozenVersion}\nnode_modules\\verpatch\\bin\\verpatch.exe dist\\sea\\certificator.exe %BUILD_VERSION% /high /pv %BUILD_VERSION% /s CompanyName "Ministry of Health Israel" /s FileDescription "MoH Israel - FHIR Certificator (Frozen Kits)" /s OriginalFilename "certificator.exe" /s ProductName "FHIR Certificator" /s InternalName "certificator"`;
    fs.writeFileSync('temp_frozen_version.bat', metaPatch);
    run('cmd /C temp_frozen_version.bat');
    fs.unlinkSync('temp_frozen_version.bat');
    console.log('[freeze] Exe metadata patched to frozen version');

    console.log('[freeze] Frozen build completed.');
  } catch (err) {
    console.error('Frozen build failed:', err.message);
    process.exitCode = 1;
  }
}

if (require.main === module) {
  main();
}
