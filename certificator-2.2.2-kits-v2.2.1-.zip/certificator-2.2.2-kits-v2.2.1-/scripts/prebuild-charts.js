const fs = require('fs-extra');
const path = require('path');
const jsonata = require('jsonata');

console.log('Pre-build script starting...');

// Paths
const chartsDir = path.join(__dirname, '..', 'charts');
const indexFile = path.join(chartsDir, '.index');
const outputFile = path.join(__dirname, '..', 'src', 'helpers', 'chartExpressions.json');

console.log('Charts dir:', chartsDir);
console.log('Index file:', indexFile);
console.log('Output file:', outputFile);

// Track errors
let hasErrors = false;
const errors = [];

function logError (message) {
  hasErrors = true;
  errors.push(message);
  console.error(`❌ ${message}`);
}

function logSuccess (message) {
  console.log(`✅ ${message}`);
}

function logInfo (message) {
  console.log(`ℹ️  ${message}`);
}

async function validateJsonataFile (filePath) {
  try {
    const content = await fs.readFile(filePath, 'utf8');
    // Only parse, don't evaluate - this checks syntax without needing bound variables
    jsonata(content);
    return true;
  } catch (error) {
    logError(`Syntax error in ${path.basename(filePath)}: ${error.message}`);
    return false;
  }
}

async function readIndexFile () {
  try {
    if (!await fs.exists(indexFile)) {
      logError(`Index file not found: ${indexFile}`);
      return null;
    }

    const content = await fs.readFile(indexFile, 'utf8');
    const chartNames = content.trim().split('\n').map(line => line.trim()).filter(line => line.length > 0);

    // Convert chart names to filenames by adding .jsonata extension
    const chartFiles = chartNames.map(name => `${name}.jsonata`);

    logSuccess(`Index file loaded with ${chartFiles.length} chart entries`);
    return chartFiles;
  } catch (error) {
    logError(`Failed to read index file: ${error.message}`);
    return null;
  }
}

async function getJsonataFiles () {
  try {
    const files = await fs.readdir(chartsDir);
    return files.filter(file => file.endsWith('.jsonata'));
  } catch (error) {
    logError(`Failed to read charts directory: ${error.message}`);
    return [];
  }
}

async function main () {
  logInfo('Starting chart expressions pre-build validation...');

  // Read index file
  const chartOrder = await readIndexFile();
  if (!chartOrder) {
    process.exit(1);
  }

  // Get all .jsonata files
  const jsonataFiles = await getJsonataFiles();
  logInfo(`Found ${jsonataFiles.length} .jsonata files in charts directory`);

  // Validate that all files in index exist
  for (const chartFile of chartOrder) {
    if (!jsonataFiles.includes(chartFile)) {
      logError(`Chart file referenced in index but not found: ${chartFile}`);
    }
  }

  // Validate syntax of all .jsonata files
  const chartExpressions = {};
  let validatedCount = 0;

  for (const file of jsonataFiles) {
    const filePath = path.join(chartsDir, file);
    logInfo(`Validating syntax: ${file}`);

    if (await validateJsonataFile(filePath)) {
      logSuccess(`✓ ${file}`);
      validatedCount++;

      // Read content for output
      const content = await fs.readFile(filePath, 'utf8');
      const key = path.basename(file, '.jsonata');
      chartExpressions[key] = content;
    }
  }

  // Check for files not in index (error - all files must be referenced)
  const filesNotInIndex = jsonataFiles.filter(file => !chartOrder.includes(file));
  if (filesNotInIndex.length > 0) {
    logError(`Chart files not referenced in index: ${filesNotInIndex.join(', ')}`);
    logError('All .jsonata files must be referenced in the index file. Either add them to charts/.index or remove the unused files.');
  }

  // Generate output file if no errors
  if (!hasErrors) {
    // Create ordered expressions array based on index
    const orderedExpressions = [];
    for (const chartFile of chartOrder) {
      const key = path.basename(chartFile, '.jsonata');
      if (chartExpressions[key]) {
        orderedExpressions.push({
          chartFilename: chartFile,
          expression: chartExpressions[key]
        });
      }
    }

    await fs.writeFile(outputFile, JSON.stringify(orderedExpressions, null, 2));
    logSuccess(`Generated chart expressions array: ${path.relative(process.cwd(), outputFile)}`);
    logSuccess(`Successfully validated ${validatedCount}/${jsonataFiles.length} chart expressions`);

    console.log('\n🎉 Pre-build chart validation completed successfully!');
  } else {
    console.log('\n💥 Pre-build chart validation failed with errors:');
    errors.forEach(error => console.log(`   • ${error}`));
    process.exit(1);
  }
}

// Run the script
main().catch(error => {
  console.error('💥 Unexpected error:', error);
  process.exit(1);
});
