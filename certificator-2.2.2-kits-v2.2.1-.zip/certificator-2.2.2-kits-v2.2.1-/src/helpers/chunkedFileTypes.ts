// file types that should be sent using a write stream
export const isFiletypeChunked = {
  '.js': true,
  '.ttf': true,
  '.ico': true,
  '.css': true,
  '.svg': true
};
