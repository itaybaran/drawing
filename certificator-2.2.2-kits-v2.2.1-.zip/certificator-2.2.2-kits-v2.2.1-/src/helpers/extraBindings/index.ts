// additional function to bind and use within expressions
import { http } from '../fhirServer/client';
import { writeFile, readFile, makeDir, readDir, resolveCanonical, readPackageIndex } from './io';
import { toMarkdown } from './markdown';
import { validate } from './validate';
import { fumeUtils } from 'fume-fhir-converter';
import { appendFile, writeFile as fsWriteFile } from 'fs/promises';
import path from 'path';

const instant = () => Date.now();
const setStatus = () => {}; // noop for dev mode. overridden with actual func when invoked as an action

/**
 * Factory: creates a mutable, Map-like cache object for use inside JSONata expressions.
 * Usage inside JSONata:
 *   (
 *     $cache := $newCache();
 *     /* mutate state using the variable's methods (these DO update internal state) *-/
 *     $cache.set('a', 1);
 *     $cache.update('a', function($cur){ ($cur ? $cur : 0) + 2 });
 *     /* retrieve values *-/
 *     $cache.get('a'); /* 3 *-/
 *     /* export to plain object for further JSONata processing *-/
 *     $cache.toObject()
 *   )
 *
 * Notes:
 * - You must assign the result of $newCache() to a variable and then call that variable's methods.
 * - Methods intentionally mutate the cache's internal state even though JSONata is declarative.
 */
const newCache = (initial?: any) => {
  const map = new Map<any, any>();

  // Initialize from entries array or plain object
  if (Array.isArray(initial)) {
    // Expecting [[key, value], ...]
    for (const entry of initial) {
      if (Array.isArray(entry) && entry.length >= 2) {
        map.set(entry[0], entry[1]);
      }
    }
  } else if (initial && typeof initial === 'object') {
    for (const [k, v] of Object.entries(initial)) {
      map.set(k, v);
    }
  }

  // Map-like API exposed to expressions
  return {
    /** set(key, value): stores a value and returns the stored value */
    set: (key: any, value: any) => {
      map.set(key, value);
      return value;
    },
    /** get(key, default?): returns value or default if missing */
    get: (key: any, def?: any) => (map.has(key) ? map.get(key) : def),
    /** has(key): boolean */
    has: (key: any) => map.has(key),
    /** delete(key): boolean */
    delete: (key: any) => map.delete(key),
    /** clear(): empties cache; returns null (useful when chaining in JSONata) */
    clear: () => {
      map.clear();
      return null;
    },
    /** size(): number of entries */
    size: () => map.size,
    /** keys(): array of keys */
    keys: () => Array.from(map.keys()),
    /** values(): array of values */
    values: () => Array.from(map.values()),
    /** entries(): array of { key, value } objects for easy JSONata consumption */
    entries: () => Array.from(map.entries()).map(([key, value]) => ({ key, value })),
    /** getOrSet(key, init | function): returns existing or initializes then returns */
    getOrSet: (key: any, init: any) => {
      if (map.has(key)) return map.get(key);
      const val = typeof init === 'function' ? init() : init;
      map.set(key, val);
      return val;
    },
    /** update(key, updater): updater(current | undefined) -> next; stores and returns next */
    update: (key: any, updater: (current: any) => any) => {
      const current = map.get(key);
      const next = typeof updater === 'function' ? updater(current) : updater;
      map.set(key, next);
      return next;
    },
    /** toObject(): convert to plain object (keys are stringified) */
    toObject: () => {
      const obj: any = {};
      for (const [k, v] of map.entries()) obj[String(k)] = v;
      return obj;
    }
  };
};

// Check if FHIR tracing is enabled
const isFhirTracingEnabled = () => {
  return process.env.ENABLE_FHIR_TRACING?.toLowerCase() === 'true';
};

// Simple trace logger
const traceLog = async (functionName: string, params: any) => {
  if (!isFhirTracingEnabled()) return;

  const timestamp = new Date().toISOString();
  const traceObject = {
    functionName,
    timestamp,
    params
  };
  const logEntry = `${JSON.stringify(traceObject)},\n`;
  try {
    await appendFile(path.join(process.cwd(), 'fhir-trace.log'), logEntry);
  } catch (err) {
    console.warn('Failed to write trace log:', err);
  }
};

// Reset trace log file (called at start of kit runs)
export const resetTraceLog = async (runTimestamp?: string) => {
  if (!isFhirTracingEnabled()) return;

  try {
    const timestamp = new Date().toISOString();
    const runInfo = runTimestamp ? ` (Run: ${runTimestamp})` : '';
    const logHeader = `// FHIR Trace Log Started at ${timestamp}${runInfo}\n// To convert to valid JSON: remove this comment, remove the last comma, and wrap all entries in [ ]\n`;
    await fsWriteFile(path.join(process.cwd(), 'fhir-trace.log'), logHeader);
  } catch (err) {
    console.warn('Failed to reset trace log:', err);
  }
};

// Check if trace file belongs to a specific run timestamp
export const traceFileBelongsToRun = async (runTimestamp: string): Promise<boolean> => {
  if (!isFhirTracingEnabled()) return false;

  try {
    const traceFilePath = path.join(process.cwd(), 'fhir-trace.log');
    const { access } = await import('fs/promises');
    await access(traceFilePath);

    const { readFile } = await import('fs/promises');
    const firstLine = (await readFile(traceFilePath, 'utf8')).split('\n')[0];

    // Check if the first line contains our run timestamp
    return firstLine.includes(`(Run: ${runTimestamp})`);
  } catch (err) {
    // File doesn't exist or can't be read
    return false;
  }
};

// Conditionally create traced or original functions based on environment variable
const createHttpBinding = () => {
  if (!isFhirTracingEnabled()) {
    return http;
  }

  return async (options: any) => {
    await traceLog('$http', options);
    return await http(options);
  };
};

const createSearchBinding = () => {
  if (!isFhirTracingEnabled()) {
    return fumeUtils.search;
  }

  return async (resourceType: any, params?: any) => {
    await traceLog('$search', { resourceType, params });
    const result = await fumeUtils.search(resourceType, params);
    return result;
  };
};

const createResolveBinding = () => {
  if (!isFhirTracingEnabled()) {
    return fumeUtils.resolve;
  }

  return async (reference: any) => {
    await traceLog('$resolve', { reference });
    const result = await fumeUtils.resolve(reference);
    return result;
  };
};

const createLiteralBinding = () => {
  if (!isFhirTracingEnabled()) {
    return fumeUtils.literal;
  }

  return async (value: any) => {
    await traceLog('$literal', { value });
    const result = await fumeUtils.literal(value);
    return result;
  };
};

const createSearchSingleBinding = () => {
  if (!isFhirTracingEnabled()) {
    return fumeUtils.searchSingle;
  }

  return async (resourceType: any, params?: any) => {
    await traceLog('$searchSingle', { resourceType, params });
    const result = await fumeUtils.searchSingle(resourceType, params);
    return result;
  };
};

export const extraBindings = {
  setStatus,
  instant,
  validate,
  newCache,
  http: createHttpBinding(),
  search: createSearchBinding(),
  resolve: createResolveBinding(),
  literal: createLiteralBinding(),
  searchSingle: createSearchSingleBinding(),
  writeFile,
  readFile,
  makeDir,
  readDir,
  resolveCanonical,
  readPackageIndex,
  toMarkdown
};
