import axios, { AxiosHeaders, AxiosInstance } from 'axios';

export interface HttpOptions {
  method: string
  header?: Record<string, string> // deprecated, use headers instead
  headers?: Record<string, string>
  url?: string
  baseUrl?: string
  body?: any
  data?: any // data is a fallback for body (to align with axios)
  params?: Record<string, string>
  timeout?: number
};

const baseURL = process.env.FHIR_SERVER_BASE;

const createAuthHeader = (authType: string, username?: string, password?: string): string | undefined => {
  if (authType === 'BASIC' && username && password && username > '' && password > '') {
    const buff = Buffer.from(`${username}:${password}`, 'utf-8');
    return `Basic ${buff.toString('base64')}`;
  } else {
    return undefined;
  }
};

const authHeader: string | undefined = createAuthHeader(
  process.env.FHIR_SERVER_AUTH_TYPE,
  process.env.FHIR_SERVER_UN,
  process.env.FHIR_SERVER_PW
);

const timeout = process.env.FHIR_SERVER_TIMEOUT ? parseInt(process.env.FHIR_SERVER_TIMEOUT, 10) : 30000;

export const server: AxiosInstance = axios.create({
  baseURL,
  timeout,
  validateStatus: () => true // Don't fail on HTTP error status codes
});

// request interceptor to add Authorization header if needed
server.interceptors.request.use(config => {
  // Axios may use either a plain object or AxiosHeaders, normalize it
  if (!config.headers || !(config.headers instanceof AxiosHeaders)) {
    config.headers = new AxiosHeaders(config.headers);
  }

  if (authHeader) {
    config.headers.set('Authorization', authHeader);
  }

  return config;
});

export const http = async (options: HttpOptions) => {
  if (options?.body && options.data) {
    throw new Error('http: cannot specify both `body` and `data`');
  }
  if (options?.header && options.headers) {
    throw new Error('http: cannot specify both `header` and `headers`');
  }
  try {
    if (server) {
      const requestConfig = {
        url: '/' + (options.url ?? ''),
        method: options.method,
        baseURL: options.baseUrl ?? baseURL,
        headers: { ...(options.headers ?? options.header ?? {}) },
        params: options.params,
        data: options.body ?? options.data,
        timeout: options.timeout ?? timeout
      };

      const response = await server.request(requestConfig);

      if (response.status >= 400) {
        console.error(`Error: ${response.status} - ${response.statusText}`);
        console.error('Request URL:', response.config.url, 'Base URL:', response.config.baseURL, 'Method:', response.config.method);
      }

      delete response.config;
      delete response.request;
      return response;
    }
  } catch (e) {
    console.error(e);
    return e;
  }
  return undefined;
};
