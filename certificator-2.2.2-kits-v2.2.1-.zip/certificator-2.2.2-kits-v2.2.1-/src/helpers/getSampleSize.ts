export const sampleSize = process.env?.RESOURCE_SAMPLE_SIZE ? parseInt(process.env?.RESOURCE_SAMPLE_SIZE) : 1000;
