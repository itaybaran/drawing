export const strongIdentifierSystems = typeof process.env?.STRONG_IDENTIFIER_SYSTEMS === 'string'
  ? (
    process.env.STRONG_IDENTIFIER_SYSTEMS.split(',').map(system => system.trim()).filter(system => system.length > 0)
  )
  : [];
