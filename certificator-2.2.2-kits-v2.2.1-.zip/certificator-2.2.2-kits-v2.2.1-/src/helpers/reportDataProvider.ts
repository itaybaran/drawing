import jsonata from 'jsonata';
import type { Expression } from 'jsonata';

// This expression now ONLY builds the base charts derived from the current workflow & kit tree.
// Dynamic charts defined in chartExpressions.json are evaluated safely (individually) in TypeScript.
export const getReportData: Expression = jsonata(`(
  $kitName := $kits.kits[id=$kitId].name;

  $flatKit := kit.children.children.children.{
    'testId': id,
    'testName': name,
    'subGroupId': %.id,
    'subGroupName': %.name,
    'groupId': %.%.id,
    'groupName': %.%.name
  };

  $getTestMetadata := function($testId){(
    $flatKit[testId = $testId]
  )};

  $skippedTests := {
    'id': 'skipped-tests',
    'title': 'Skipped Tests',
    'type': 'table',
    'columns': [
      {'property': 'group','label': 'Group'},
      {'property': 'subGroup','label': 'Sub Group'},
      {'property': 'test','label': 'Test Name'}
    ],
    'data': [workflow.tests[skipped = true].(
      $testId := testId;
      $testMeta := $getTestMetadata($testId);
      $testMeta.{
        'group': groupName,
        'subGroup': subGroupName,
        'test': testName
      }
    )]
  };

  $runSummary := {
    'id': 'run-summary',
    'title': 'Run Summary',
    'type': 'table',
    'columns': [
      {'property': 'group','label': 'Group'},
      {'property': 'subGroup','label': 'Sub Group'},
      {'property': 'testId','label': 'Test ID'},
      {'property': 'test','label': 'Test Name'},
      {'property': 'status','label': 'Status'},
      {'property': 'details','label': 'Details'}
    ],
    'data': [workflow.tests[skipped=false].(
      $testId := testId;
      $status := $getTestStatusText($testId);
      $testMeta := $getTestMetadata($testId);
      $testMeta.{
        'group': groupName,
        'subGroup': subGroupName,
        'test': testName,
        'status': $status,
        'testId' : $testId,
        'details': $getTestErrorDetails($testId)
      }
    )]
  };

  $statusPie := {
    'id': 'test-pie',
    'title': 'Test Status Summary',
    'type': 'pie',
    'data': [($runSummary.data{status: $count($)} ~> $spread()).{
      'label': $keys($),
      'value': *
    }]
  };

  $runAttributes := {
    'id': 'run-attributes',
    'title': 'Run Attributes',
    'type': 'table',
    'columns': [
      {'property': 'key','label': 'Attribute'},
      {'property': 'value','label': 'Value'}
    ],
    'data': [
      {'key': 'Kit Name','value': $kitName},
      {'key': 'Skipped Tests','value': $string($count($skippedTests.data))},
      {'key': 'Execution Date','value': $substringBefore(workflow.timestamp, '_')},
      {'key': 'Execution Time','value': $substring(workflow.timestamp, 11,2) & ':' & $substring(workflow.timestamp, 13,2) & ':' & $substring(workflow.timestamp, 15,2)},
      {'key': 'Certificator Version','value': $certificatorVersion},
      {'key': 'Resource Sample Size','value': $sampleSize},
      {'key': 'User Name','value': $username},
      {'key': 'User Domain','value': $userDomain},
      {'key': 'FHIR Server','value': $fhirServer},
      {'key': 'Client Host Name','value': $hostName}
    ]
  };

  {
    'charts': [
      $runAttributes,
      $count($skippedTests.data) > 0 ? $skippedTests,
      $runSummary,
      $statusPie
    ]
  }
)`);
